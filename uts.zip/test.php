<?php
session_start();
?>

<!DOCTYPE html>
<html>
    Hello World

    <?php
    echo $_SESSION['loginstatus'];
    ?>
</html>