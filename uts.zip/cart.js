function addtocart() {
    alert("Added to cart!");
}

function deletcart() {
    alert("Item removed!");
}